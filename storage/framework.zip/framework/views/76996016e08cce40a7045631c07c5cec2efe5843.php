<?php $__env->startSection('page-title'); ?>
    Vendor - Big V
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-title'); ?>
    <?php echo e($vendor->name); ?> - BigV
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-description'); ?>
    <?php echo e($vendor->description); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-image'); ?>
    <?php echo e(asset('uploads/'.$vendor->photo)); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head-extra'); ?>
    <link href="<?php echo e(asset('assets/css/style-product-list.css')); ?>" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content" style="width: 100vw; min-width: 0 !important; max-width: 1200px; margin:auto auto 20vh auto;">
        <div class="vendor-details row" style="gap:0 !important; margin: 0 !important; width: 100%;">
            <div class="vendor-left-column col-sm-12 col-md-4 mb-4 ">
                <div class="w-100 d-flex justify-content-center">
                    <img src="<?php echo e(asset('uploads/'.$vendor->photo)); ?>" class="w-100" style="max-width:300px; border-radius: 27px;"
                        alt="">
                </div>
            </div>
            <div class="col-sm-12 col-md-8">
                <div class="pricing-content">
                    <div class="tagline"><strong>Location</strong>: <?php echo e($vendor->location->name); ?></div>
                    <div class="pricing-info">
                        <h3 class="orange-text"><?php echo e($vendor->name); ?></h3>
                    </div>
                    <div class="pricing-divider-two"></div>
                    <div class="pricing-details">
                        <div class="pricing-block">
                            <p class="pricing-details-text">Transactions</p>
                            <p class="tagline"><?php echo e($vendor->items_sold); ?></p>
                        </div>
                        <div class="pricing-block">
                            <p class="pricing-details-text">Rating</p>
                            <div class="product-card-stars">
                                <?php ($arr_rating = explode('.', $vendor->rating)); ?>
                                <?php ($first_num = $arr_rating[0]); ?>
                                <?php while($first_num > 0): ?>
                                    <img src="<?php echo e(asset('assets/Star 1.svg')); ?>" loading="lazy" alt=""
                                        class="card-stars" />
                                    <?php ($first_num--); ?>
                                <?php endwhile; ?>

                                <?php if(isset($arr_rating[1])): ?>
                                    <img src="<?php echo e(asset('assets/Star 2.svg')); ?>" loading="lazy" alt=""
                                        class="card-stars" />
                                <?php endif; ?>

                                <?php ($remaining_rating = explode('.', 5 - $vendor->rating)[0]); ?>
                                <?php if($remaining_rating > 0): ?>
                                    <?php while($remaining_rating > 0): ?>
                                        <img src="<?php echo e(asset('assets/Star 3.svg')); ?>" loading="lazy" alt=""
                                            class="card-stars" />
                                        <?php ($remaining_rating--); ?>
                                    <?php endwhile; ?>
                                <?php endif; ?>
                            </div>
                            <p class="tagline"><?php echo e($vendor->rating); ?></p>
                        </div>
                        <div class="pricing-block">
                            <p class="pricing-details-text">Products</p>
                            <p class="tagline"><?php echo e($vendor->products->count()); ?> products</p>
                        </div>
                    </div>
                    <p>
                    <?php echo nl2br(e($vendor->description)); ?>

                    </p>
                </div>
            </div>
        </div>
        <div style="display:flex; flex-direction: column; align-items:center;width: calc(100% - 288px);">
            <div class="products-archive-grid" id="productsList">
                <?php (date_default_timezone_set('Asia/Singapore')); ?>
                <?php ($dateNow = new DateTime(date("Y-m-d H:i:s"))); ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('product.show', $product->id)); ?>" class="text-style-none">
                        <div id="w-node-_98aa59c7-5c20-8fcb-852c-972bad093e75-fac73a6c" class="product-card padding-small">
                            <div class="text-rich-text text-size-small text-color-grey"><?php echo e($product->vendor->name); ?></div><img
                                src="<?php echo e(asset('uploads/'.$product->featured_image)); ?>" loading="lazy" alt="" class="product-image" />
                            <div class="product-card-stars">
                                <?php ($arr_rating = explode('.', $product->rating)); ?>
                                <?php ($first_num = $arr_rating[0]); ?>
                                <?php while($first_num > 0): ?>
                                    <img src="<?php echo e(asset('assets/Star 1.svg')); ?>" loading="lazy" alt="" class="card-stars" />
                                    <?php ($first_num--); ?>
                                <?php endwhile; ?>
            
                                <?php if(isset($arr_rating[1])): ?>
                                    <img src="<?php echo e(asset('assets/Star 2.svg')); ?>" loading="lazy" alt="" class="card-stars" />
                                <?php endif; ?>
            
                                <?php ($remaining_rating = explode('.', 5 - $product->rating)[0]); ?>
                                <?php if($remaining_rating > 0): ?>
                                    <?php while($remaining_rating > 0): ?>
                                        <img src="<?php echo e(asset('assets/Star 3.svg')); ?>" loading="lazy" alt="" class="card-stars" />
                                        <?php ($remaining_rating--); ?>
                                    <?php endwhile; ?>
                                <?php endif; ?>
                            </div>
                            <div
                                class="product-card-title text-rich-text text-size-regular text-weight-bold text-color-dark-grey text-center text-truncate">
                                <?php echo e($product->name); ?>

                            </div>
                            <div class="product-card-low-div">
                                <?php if(count($product->variations) <= 1): ?>
                                    <?php if($product->variations[0]->discount != 0): ?>
                                        <?php ($startDate = new DateTime($product->variations[0]->discount_start_date)); ?>
                                        <?php ($endDate = new DateTime($product->variations[0]->discount_end_date)); ?>
                                        
                                        <?php if($startDate <= $dateNow && $dateNow <= $endDate): ?>
                                            <div class="card-discount">
                                                <!--<div class="discount">-$<?php echo e($product->variations[0]->discount); ?></div>-->
                                                <div class="discount">Sale</div>
                                            </div>
                                            <div id="w-node-_98aa59c7-5c20-8fcb-852c-972bad093e85-fac73a6c"
                                                class="sale-price text-color-light-grey" style="padding: 0.25em;">
                                                $<?php echo e(number_format($product->variations[0]->price, 2, ".", ",")); ?></div>
                                            <div class="text-rich-text text-color-orange text-weight-bold" style="padding: 0.25em;">
                                                $<?php echo e(number_format($product->variations[0]->discount, 2, ".", ",")); ?></div>
                                        <?php else: ?>
                                            <div class="text-rich-text text-color-orange text-weight-bold" style="padding: 0.25em;">
                                                $<?php echo e(number_format($product->variations[0]->price, 2, ".", ",")); ?></div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <div class="text-rich-text text-color-orange text-weight-bold" style="padding: 0.25em;">
                                            $<?php echo e(number_format($product->variations[0]->price, 2, ".", ",")); ?></div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php ($salePriceAvailable = false); ?>
                                    <?php $__currentLoopData = $product->variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($pv->discount != 0): ?>
                                            <?php ($startDate = new DateTime($product->variations[0]->discount_start_date)); ?>
                                            <?php ($endDate = new DateTime($product->variations[0]->discount_end_date)); ?>
                                            
                                            <?php if($startDate <= $dateNow && $dateNow <= $endDate): ?>
                                                <?php ($salePriceAvailable = true); ?>
                                                <?php break; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php if($salePriceAvailable): ?>
                                        <div class="card-discount">
                                            <!--<div class="discount">-$<?php echo e($product->variations[0]->discount); ?></div>-->
                                            <div class="discount">Sale</div>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php if(($product->variations->max('price') - $product->variations->min('price')) != 0): ?>
                                    <div class="text-rich-text text-color-orange text-weight-bold" style="padding: 0.25em; white-space:nowrap;">
                                                    $<?php echo e(number_format($product->variations->min('price'), 2, ".", ",")); ?> - $<?php echo e(number_format($product->variations->max('price'), 2, ".", ",")); ?>

                                                </div>
                                    <?php else: ?>
                                    <div class="text-rich-text text-color-orange text-weight-bold" style="padding: 0.25em; white-space:nowrap;">
                                                    $<?php echo e(number_format($product->variations->min('price'), 2, ".", ",")); ?>

                                                </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($products->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript-extra'); ?>
    <script src="<?php echo e(asset('assets/js/script-product-list.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bigvsgco/public_html/resources/views/user/vendor/detail.blade.php ENDPATH**/ ?>
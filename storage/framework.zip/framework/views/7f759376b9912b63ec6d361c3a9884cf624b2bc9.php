<?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $productReview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(!$loop->first): ?>
        <div class="divider-dash mt-2 mb-2"></div>
    <?php endif; ?>
    <div class="row mt-2 mb-2">
        <div class="col-2">
            <div id="carouselReview<?php echo e($key); ?>" class="carousel slide d-flex align-items-center"
                data-ride="carousel">
                <div class="carousel-inner br-18">
                    <?php $__currentLoopData = $productReview->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item active">
                            <img class="d-block w-100" src="<?php echo e(asset('uploads/' . $image->link)); ?>" alt="First slide">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <a class="carousel-control-prev" href="#carouselReview<?php echo e($key); ?>" role="button"
                    data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselReview<?php echo e($key); ?>" role="button"
                    data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
        <div class="col-10 m-0 d-flex flex-column justify-content-center">
            <h5 class="m-0"><?php echo e($productReview->user->name); ?></h5>
            <div class="d-flex">
                <i style="margin-top: 1px;" class="fas fa-star mr-1 font-14"></i>
                <h6 class="m-0"><?php echo e($productReview->rating); ?></h6>
            </div>
            <small class="mt-2 mb-0"><?php echo e($productReview->description); ?></small>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($reviews->links()); ?>

<?php /**PATH /home/bigvsgco/public_html/resources/views/admin/manage/product/inc/review.blade.php ENDPATH**/ ?>
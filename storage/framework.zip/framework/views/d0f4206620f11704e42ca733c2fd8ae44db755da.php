<div class="card-body">
    <div class="table-responsive">
        <table id="zero_config" class="table table-striped">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Date</th>
                    <th>Total Items</th>
                    <th>Total Spent</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="align-middle">
                            <a href="<?php echo e(route('admin.transaction.show', $transaction->id)); ?>"><?php echo e($transaction->id); ?></a>
                        </td>
                        <td><?php echo e(date_format(date_create($transaction->created_at), 'd/m/Y')); ?></td>
                        <td class="align-middle"><?php echo e($transaction->sold_count); ?></td>
                        <td class="align-middle">$<?php echo e($transaction->total_price); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($transactions->links()); ?>

</div>
<?php /**PATH /home/bigvsgco/public_html/resources/views/admin/analytics/orders/inc/transaction.blade.php ENDPATH**/ ?>
<?php $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="discount-div-claim">
        <div class="div-block-30-copy">
            <h4 class="heading-7"><?php echo e($discount->code); ?></h4>
        </div>
        <div class="text-size-small"><?php echo e($discount->description); ?></div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/bigvsgco/public_html/resources/views/user/promo/inc/discount.blade.php ENDPATH**/ ?>
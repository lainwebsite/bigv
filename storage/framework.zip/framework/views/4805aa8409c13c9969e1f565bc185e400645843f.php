<?php $__currentLoopData = $variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="d-flex align-items-center justify-content-between product-result-voucher cursor-pointer"
        onclick="selectVoucherProduct(<?php echo e($variation->id); ?>, '<?php echo e(asset('uploads/' . $variation->product->featured_image)); ?>', '<?php echo e($variation->product->name); ?> - <?php echo e($variation->name); ?>',  '<?php echo e($variation->product->category->name); ?>');">
        <div class="d-flex align-items-center">
            <div class="d-flex align-items-center">
                <img class="d-flex br-18 mr-3" src="<?php echo e(asset('uploads/') . '/' . $variation->product->featured_image); ?>"
                    height="60" width="60" alt="Generic placeholder image">
                <div class="d-flex justify-content-center flex-column">
                    <h5 class="m-0"><b><?php echo e($variation->product->name); ?> - <?php echo e($variation->name); ?></b></h5>
                    <small class="m-0"><?php echo e($variation->product->category->name); ?></small>
                </div>
            </div>
        </div>
    </div>
    <div class="divider-dash"></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/bigvsgco/public_html/resources/views/admin/manage/discounts/inc/voucher_product.blade.php ENDPATH**/ ?>
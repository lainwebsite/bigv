<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="d-flex align-items-center justify-content-between category-result-product-voucher cursor-pointer"
        onclick="selectVoucherCategory(<?php echo e($category->id); ?>, '<?php echo e(asset('uploads/' . $category->photo_url)); ?>', '<?php echo e($category->name); ?>',  '<?php echo e($category->products->count()); ?>');">
        <div class="d-flex align-items-center">
            <div class="d-flex justify-content-center flex-column">
                <h5 class="m-0"><b><?php echo e($category->name); ?></b></h5>
            </div>
        </div>
        <p class="m-0">Total Product <b><?php echo e($category->products->count()); ?></b></p>
    </div>
    <div class="divider-dash"></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/bigvsgco/public_html/resources/views/admin/manage/discounts/inc/voucher_category.blade.php ENDPATH**/ ?>
<?php $__env->startSection('page-title'); ?>
    Product - BigV
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-title'); ?>
    Products - BigV
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-description'); ?>
    Shop BigV Products Here!
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-image'); ?>
    <?php echo e(asset('assets/62ffbe41b946fc3a2b7b6747_Big%20V(NoTag)-ColorB%202.png')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head-extra'); ?>
    <link href="<?php echo e(asset('assets/css/style-product-list.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content" style="width: 100vw; min-width: 0 !important; max-width: 1200px; margin:auto;">
        <div class="flex flex-vertical row-gap margin-large" style="width: 85%; min-width: 980px; position:relative;">
            <div class="text-align-center orange-text">Showing search result for</div>
            <h3 class="text-align-center">
                <?php if(app('request')->input('keyword') != ""): ?>
                "<?php echo e(app('request')->input('keyword')); ?>"
                <?php else: ?>
                Products
                <?php endif; ?>
            </h3>
            
            <div class="sort-right">
                <div class="text-rich-text text-size-small text-color-grey" style="margin-right: 20px;">Sort By</div>
                <select class="sort" style="padding: 5px 15px; border-radius: 18px;">
                    <option value="items_sold"
                        <?php if(isset($sort_by)): ?> <?php if($sort_by == 'items_sold'): ?> selected <?php endif; ?> <?php endif; ?>>Items Sold</option>
                    <option value="highest_price"
                        <?php if(isset($sort_by)): ?> <?php if($sort_by == 'highest_price'): ?> selected <?php endif; ?> <?php endif; ?>>Highest Price</option>
                    <option value="lowest_price"
                        <?php if(isset($sort_by)): ?> <?php if($sort_by == 'lowest_price'): ?> selected <?php endif; ?> <?php endif; ?>>Lowest Price</option>
                </select>
                
            </div>
        </div>

        <?php if(isset($category)): ?>
            
            <?php if($category != ''): ?>
                <?php ($checkedCategories = explode(',', $category)); ?>
            <?php endif; ?>
        <?php endif; ?>

        <div>
            <div class="flex flex-center top-align relative archive-flex"
                style="width: 100vw; min-width: 0 !important; max-width: 1200px;margin: 0 auto 60px auto;;">
                <div class="filter card27 padding-small text-color-grey sticky-filter" style="padding: 2rem;">
                    <h4>Categories</h4>
                    <div class="w-form">
                        <form id="formFilter1" name="email-form-2" data-name="Email Form 2" method="GET"
                            class="form-2 w-clearfix" action="<?php echo e(url('product/filter')); ?>">
                            <?php $__currentLoopData = $productCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="w-checkbox">
                                    <?php if(isset($checkedCategories)): ?>
                                        <?php ($checking = false); ?>
                                        <?php $__currentLoopData = $checkedCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $checked): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($checked == $productCategory->id): ?>
                                                <div
                                                    class="w-checkbox-input w-checkbox-input--inputType-custom checkbox w--redirected-checked">
                                                </div>
                                                <?php ($checking = true); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php if($checking == false): ?>
                                            <div class="w-checkbox-input w-checkbox-input--inputType-custom checkbox"></div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <div class="w-checkbox-input w-checkbox-input--inputType-custom checkbox"></div>
                                    <?php endif; ?>
                                    <input type="checkbox" id="checkbox-<?php echo e($productCategory->id + 1); ?>"
                                        class="checkbox-category" style="opacity:0;position:absolute;z-index:-1"
                                        value="<?php echo e($productCategory->id); ?>" /><span class="text-size-small w-form-label"
                                        for="checkbox-<?php echo e($productCategory->id + 1); ?>"><?php echo e($productCategory->name); ?></span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <label for="email">Price</label>
                            <div class="flex justify-left" style="gap: 5px;">
                                <div class="relative">
                                    <input type="number" class="min-price quantity-pill-small price-range-filter"
                                        min="0"
                                        <?php if(isset($min_price)): ?> value="<?php echo e($min_price != 0 ? $min_price : ''); ?>" <?php endif; ?>>
                                    <p class="float-price">$</p>
                                </div>
                                <p class="margin-0">-</p>
                                <div class="relative">
                                    <input type="number" class="max-price quantity-pill-small price-range-filter"
                                        min="0"
                                        <?php if(isset($max_price)): ?> value="<?php echo e($max_price != 0 ? $max_price : ''); ?>" <?php endif; ?>>
                                    <p class="float-price">$</p>
                                </div>
                            </div>
                            <button type="submit" class="btn-filter-1 submit-button atc-button margin-top w-button"
                                style="margin-top: 20px;">Filter</button>
                        </form>
                    </div>
                </div>
                <div data-animation="default" data-collapse="medium" data-duration="400" data-easing="ease"
                    data-easing2="ease" role="banner" class="navbar-4 w-nav">
                    <div class="container-3 w-container">
                        <nav role="navigation" class="nav-menu-3 w-nav-menu">
                            <div class="filter card27 padding-small text-color-grey filter-hamburger">
                                <h3>Categories</h3>
                                <div class="w-form">
                                    <form id="formFilter2" name="email-form-2" data-name="Email Form 2" method="GET"
                                        class="form-2 w-clearfix" action="<?php echo e(url('product/filter')); ?>">
                                        <?php $__currentLoopData = $productCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label class="w-checkbox">
                                                <?php if(isset($checkedCategories)): ?>
                                                    <?php ($checking = false); ?>
                                                    <?php $__currentLoopData = $checkedCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $checked): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($checked == $productCategory->id): ?>
                                                            <div
                                                                class="w-checkbox-input w-checkbox-input--inputType-custom checkbox w--redirected-checked">
                                                            </div>
                                                            <?php ($checking = true); ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    <?php if($checking == false): ?>
                                                        <div
                                                            class="w-checkbox-input w-checkbox-input--inputType-custom checkbox">
                                                        </div>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <div
                                                        class="w-checkbox-input w-checkbox-input--inputType-custom checkbox">
                                                    </div>
                                                <?php endif; ?>
                                                <input type="checkbox" id="checkbox-<?php echo e($productCategory->id + 1); ?>"
                                                    class="checkbox-category" style="opacity:0;position:absolute;z-index:-1"
                                                    value="<?php echo e($productCategory->id); ?>" /><span
                                                    class="text-size-small w-form-label"
                                                    for="checkbox-<?php echo e($productCategory->id + 1); ?>"><?php echo e($productCategory->name); ?></span>
                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <label for="email">Price</label>
                                        <div class="flex justify-left" style="gap: 5px;">
                                            <input type="number" class="min-price quantity-pill-small price-range-filter"
                                                min="0"
                                                <?php if(isset($min_price)): ?> value="<?php echo e($min_price != 0 ? $min_price : ''); ?>" <?php endif; ?>>
                                            <p class="margin-0">-</p>
                                            <input type="number" class="max-price quantity-pill-small price-range-filter"
                                                min="0"
                                                <?php if(isset($max_price)): ?> value="<?php echo e($max_price != 0 ? $max_price : ''); ?>" <?php endif; ?>>
                                        </div>
                                        <button type="submit"
                                            class="btn-filter-2 submit-button atc-button margin-top w-button"
                                            style="margin-top: 20px;">Filter</button>
                                    </form>
                                </div>
                            </div>
                        </nav>
                        <div class="menu-button-2 w-nav-button">
                            <div class="text-color-light-grey text-size-medium">Filter</div>
                        </div>
                        <div data-hover="false" data-delay="0" class="w-dropdown">
                            <div class="text-color-light-grey w-dropdown-toggle">
                                <div class="w-icon-dropdown-toggle"></div>
                                <div class="text-size-medium">Sort</div>
                            </div>
                            <nav class="mini-sort dropdown-list w-dropdown-list">
                                <a href="#" value="items_sold" class="text-color-grey w-dropdown-link">Items
                                    Sold</a>
                                <a href="#" value="highest_price" class="text-color-grey w-dropdown-link">Highest
                                    Price</a>
                                <a href="#" value="lowest_price" class="text-color-grey w-dropdown-link">Lowest
                                    Price</a>
                            </nav>
                        </div>
                    </div>
                </div>

                <?php echo $__env->make('user.product.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript-extra'); ?>
    <script src="<?php echo e(asset('assets/js/script-product-list.js')); ?>" type="text/javascript"></script>
    <script>
        $(".sort").on("change", function() {
            if ($("input[type=hidden][name=sort_by]").length <= 0) {
                $("<input>").attr({
                    type: "hidden",
                    name: "sort_by",
                    value: $(this).val()
                }).appendTo("#formFilter1");
            } else {
                $("#formFilter1 input[type=hidden][name=sort_by]").val($(this).val());
            }

            $(".btn-filter-1").click();
        });

        $(".mini-sort a").on("click", function() {
            if ($("input[type=hidden][name=sort_by]").length <= 0) {
                $("<input>").attr({
                    type: "hidden",
                    name: "sort_by",
                    value: $(this).attr("value")
                }).appendTo("#formFilter2");
            } else {
                $("#formFilter2 input[type=hidden][name=sort_by]").val($(this).attr("value"));
            }

            $(".btn-filter-2").click();
        });

        $(".btn-filter-1, .btn-filter-2").on("click", function(e) {
            var form = "#" + $(this).parents("form").attr("id");
            var param = $(location).attr("search");

            if (param != "") {
                param = param.substring(1, param.length).split("&");
                param.forEach(function(item) {
                    var items = item.split("=");
                    if (items[0] != "page") {
                        if ($("input[type=hidden][name=" + items[0] + "]").length <= 0) {
                            $("<input>").attr({
                                type: "hidden",
                                name: items[0],
                                value: items[1]
                            }).appendTo(form);
                        }
                    }
                });
            }

            checkedCategory = "";
            $(form + " .checkbox-category").each(function() {
                if ($(this).prev().is(".w--redirected-checked")) {
                    checkedCategory += $(this).val() + ",";
                }
            });

            if ($(".checkbox-category").prev().is(".w--redirected-checked")) {
                if ($(form + " input[type=hidden][name=category]").length <= 0) {
                    $("<input>").attr({
                        type: "hidden",
                        name: "category",
                        value: (checkedCategory != '') ? checkedCategory.slice(0, -1) : ""
                    }).appendTo(form);
                } else {
                    $(form + " input[type=hidden][name=category]").val((checkedCategory != '') ? checkedCategory
                        .slice(0, -1) : "");
                }
            }

            if ($(form + " input[type=hidden][name=min_price]").length <= 0) {
                if ($(form + " .min-price").val() != '') {
                    $("<input>").attr({
                        type: "hidden",
                        name: "min_price",
                        value: $(form + " .min-price").val()
                    }).appendTo(form);
                }
            } else {
                $(form + " input[type=hidden][name=min_price]").val($(form + " .min-price").val());
            }

            if ($(form + " input[type=hidden][name=max_price]").length <= 0) {
                if ($(form + " .max-price").val() != '') {
                    $("<input>").attr({
                        type: "hidden",
                        name: "max_price",
                        value: $(form + " .max-price").val()
                    }).appendTo(form);
                }
            } else {
                $(form + " input[type=hidden][name=max_price]").val($(form + " .max-price").val());
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bigvsgco/public_html/resources/views/user/product/index.blade.php ENDPATH**/ ?>
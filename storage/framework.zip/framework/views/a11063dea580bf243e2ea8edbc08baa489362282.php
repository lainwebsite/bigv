<?php $__currentLoopData = $product_discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productDiscount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div code="<?php echo e($productDiscount->code); ?>" class="delivery-add-item w-auto mr-2 ml-2 flex-column align-items-start product-discount-button cursor-pointer">
        <h4 class="heading-7"><b><?php echo e($productDiscount->code); ?></b></h4>
        <div class="text-size-small"><b><?php echo e($productDiscount->name); ?></b></div>
        <div class="text-size-small">
            <?php if($productDiscount->voucher_type == 1): ?>
            Discount $<?php echo e($productDiscount->amount); ?>

            <?php else: ?>
            <?php echo e($productDiscount->amount); ?>% <?php if($productDiscount->max_discount != null): ?>up to $<?php echo e($productDiscount->max_discount); ?><?php endif; ?>
            <?php endif; ?>
        </div>
        <small class="text-size-small"><?php echo e($productDiscount->description); ?></small>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    $(".product-discount-button").on('click', function() {
        $(".product-discount-button").removeClass("product-discount-button-active");
        $(this).addClass("product-discount-button-active");

        $(this).parent().attr("selected-voucher", $(this).attr("code"));
    });
    
    $(".shipping-discount-button").on('click', function() {
        $(".shipping-discount-button").removeClass("shipping-discount-button-active");
        $(this).addClass("shipping-discount-button-active");
        
        $(this).parent().attr("selected-voucher", $(this).attr("code"));
    });
</script><?php /**PATH /home/bigvsgco/public_html/resources/views/user/cart/itemProductDiscCheckout.blade.php ENDPATH**/ ?>
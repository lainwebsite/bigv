<?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="d-flex align-items-center justify-content-between vendor-result-product-voucher cursor-pointer"
        onclick="selectVoucherVendor(<?php echo e($vendor->id); ?>, '<?php echo e(asset('uploads/' . $vendor->photo)); ?>', '<?php echo e($vendor->name); ?>', '<?php echo e($vendor->location->name); ?>', '<?php echo e($vendor->products->count()); ?>');">
        <div class="d-flex align-items-center">
            <img class="d-flex br-18 mr-3" src="<?php echo e(asset('uploads/' . $vendor->photo)); ?>" height="60" width="60"
                alt="Generic placeholder image">
            <div class="d-flex justify-content-center flex-column">
                <h5 class="m-0"><b><?php echo e($vendor->name); ?></b></h5>
                <small class="m-0">Location <b><?php echo e($vendor->location->name); ?></b></small>
            </div>
        </div>
        <p class="m-0">Total Product <b><?php echo e($vendor->products->count()); ?></b></p>
    </div>
    <div class="divider-dash"></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/bigvsgco/public_html/resources/views/admin/manage/discounts/inc/voucher_vendor.blade.php ENDPATH**/ ?>
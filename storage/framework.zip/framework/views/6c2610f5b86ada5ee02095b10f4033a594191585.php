<div style="display:flex; flex-direction: column; align-items:center;">
    <div class="products-archive-grid" id="productsList">
        <?php (date_default_timezone_set('Asia/Singapore')); ?>
        <?php ($dateNow = new DateTime(date("Y-m-d H:i:s"))); ?>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('product.show', $product->id)); ?>" class="text-style-none">
                <div id="w-node-_98aa59c7-5c20-8fcb-852c-972bad093e75-fac73a6c" class="product-card padding-small">
                    <div class="text-rich-text text-size-small text-color-grey"><?php echo e($product->vendor->name); ?></div><img
                        src="<?php echo e(asset('uploads/'.$product->featured_image)); ?>" loading="lazy" alt="" class="product-image" />
                    <div class="product-card-stars">
                        <?php ($arr_rating = explode('.', $product->rating)); ?>
                        <?php ($first_num = $arr_rating[0]); ?>
                        <?php while($first_num > 0): ?>
                            <img src="<?php echo e(asset('assets/Star 1.svg')); ?>" loading="lazy" alt="" class="card-stars" />
                            <?php ($first_num--); ?>
                        <?php endwhile; ?>
    
                        <?php if(isset($arr_rating[1])): ?>
                            <img src="<?php echo e(asset('assets/Star 2.svg')); ?>" loading="lazy" alt="" class="card-stars" />
                        <?php endif; ?>
    
                        <?php ($remaining_rating = explode('.', 5 - $product->rating)[0]); ?>
                        <?php if($remaining_rating > 0): ?>
                            <?php while($remaining_rating > 0): ?>
                                <img src="<?php echo e(asset('assets/Star 3.svg')); ?>" loading="lazy" alt="" class="card-stars" />
                                <?php ($remaining_rating--); ?>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div>
                    <div
                        class="product-card-title text-rich-text text-size-regular text-weight-bold text-color-dark-grey text-center text-truncate">
                        <?php echo e($product->name); ?>

                    </div>
                    <div class="product-card-low-div">
                        <?php if(count($product->variations) <= 1): ?>
                            <?php if($product->variations[0]->discount != 0): ?>
                                <?php ($startDate = new DateTime($product->variations[0]->discount_start_date)); ?>
                                <?php ($endDate = new DateTime($product->variations[0]->discount_end_date)); ?>
                                
                                <?php if($startDate <= $dateNow && $dateNow <= $endDate): ?>
                                    <div class="card-discount">
                                        <div class="discount">Sale</div>
                                    </div>
                                    <div id="w-node-_98aa59c7-5c20-8fcb-852c-972bad093e85-fac73a6c"
                                        class="sale-price text-color-light-grey" style="padding: 0.25em;">
                                        $<?php echo e(number_format($product->variations[0]->price, 2, ".", ",")); ?></div>
                                    <div class="text-rich-text text-color-orange text-weight-bold" style="padding: 0.25em;">
                                        $<?php echo e(number_format($product->variations[0]->discount, 2, ".", ",")); ?></div>
                                <?php else: ?>
                                    <div class="text-rich-text text-color-orange text-weight-bold" style="padding: 0.25em;">
                                        $<?php echo e(number_format($product->variations[0]->price, 2, ".", ",")); ?></div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="text-rich-text text-color-orange text-weight-bold" style="padding: 0.25em;">
                                    $<?php echo e(number_format($product->variations[0]->price, 2, ".", ",")); ?></div>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php ($salePriceAvailable = false); ?>
                            <?php $__currentLoopData = $product->variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($pv->discount != 0): ?>
                                    <?php ($startDate = new DateTime($product->variations[0]->discount_start_date)); ?>
                                    <?php ($endDate = new DateTime($product->variations[0]->discount_end_date)); ?>
                                    
                                    <?php if($startDate <= $dateNow && $dateNow <= $endDate): ?>
                                        <?php ($salePriceAvailable = true); ?>
                                        <?php break; ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php if($salePriceAvailable): ?>
                                <div class="card-discount">
                                    <!--<div class="discount">-$<?php echo e($product->variations[0]->discount); ?></div>-->
                                    <div class="discount">Sale</div>
                                </div>
                            <?php endif; ?>
                            
                            <?php if(($product->variations->max('price') - $product->variations->min('price')) != 0): ?>
                            <div class="text-rich-text text-color-orange text-weight-bold" style="padding: 0.25em; white-space:nowrap;">
                                            $<?php echo e(number_format($product->variations->min('price'), 2, ".", ",")); ?> - $<?php echo e(number_format($product->variations->max('price'), 2, ".", ",")); ?>

                                        </div>
                            <?php else: ?>
                            <div class="text-rich-text text-color-orange text-weight-bold" style="padding: 0.25em; white-space:nowrap;">
                                            $<?php echo e(number_format($product->variations->min('price'), 2, ".", ",")); ?>

                                        </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo e($products->links()); ?>

</div><?php /**PATH /home/bigvsgco/public_html/resources/views/user/product/products.blade.php ENDPATH**/ ?>
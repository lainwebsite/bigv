<?php $__env->startSection('page-title'); ?>
    Transaction - BigV
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-title'); ?>
    Transaction - BigV
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-description'); ?>
    Take a look at your transaction history.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-image'); ?>
    <?php echo e(asset('assets/62ffbe41b946fc3a2b7b6747_Big%20V(NoTag)-ColorB%202.png')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head-extra'); ?>
    <link href="<?php echo e(asset('assets/css/style-transaction.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content" style="min-height:55vh; width: 100%;">
        <div class="header-section">
            <h2 class="orange-text">Transactions</h2>
        </div>
        <div class="transactions-page-wrapper" style="min-height: 100vh;">
            <div class="profile-page-menu">
                <div class="flex gap-small">
                  <div><b><?php echo e(auth()->user()->name); ?></b></div>
                </div>
                <div class="div-line" style="margin:0 !important;"></div>
                <div class="w-form">
                  <div class="form-2">
                      <a href="<?php echo e(url('/profile')); ?>" class="transaction-menus text-color-grey" style="text-decoration: none; white-space:nowrap;">Profile Settings</a>
                      <a href="<?php echo e(url('/user/transaction')); ?>" class="transaction-menus text-color-grey" style="text-decoration: none;">Transactions</a>
                      <a href="<?php echo e(url('/user/user-address')); ?>" class="transaction-menus text-color-grey" style="text-decoration: none;">Addresses</a>
                      <a href="<?php echo e(url('/user/discount')); ?>" class="transaction-menus text-color-grey" style="text-decoration: none;">Promos</a>
                  </div>
                </div>
            </div>
            <div class="transactions-column">
                <div class="flex gap-small column-responsive">
                    <div>Status</div>
                    <div class="div-block-27 wrap-responsive" style="flex-wrap:wrap; gap: 9px;">
                        <a href="<?php echo e(url('user/transaction')); ?>"
                            class="delivery-button w-inline-block <?php if(!isset($status_selected)): ?> selected <?php endif; ?>">
                            <div>All</div>
                        </a>
                        <?php $__currentLoopData = $transaction_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(url('user/transaction/filter?status=' . $status->id)); ?>"
                                class="delivery-button w-inline-block <?php if(isset($status_selected)): ?> <?php if($status_selected == $status->id): ?> selected <?php endif; ?> <?php endif; ?>">
                                <div><?php echo e($status->name); ?></div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="transaction-card transaction-hover-style" style="width: 100%;">
                        <a class="transaction-detail" href="<?php echo e(url('user/transaction/' . $transaction->id)); ?>"
                            style="text-decoration: none; display: none;"></a>
                        <div class="flex space-between">
                            <div class="flex gap-small">
                                <div>
                                    <h5 class="text-color-dark-grey">Transaction ID: <?php echo e($transaction->id); ?></h5>
                                    <div class="text-size-small text-color-grey">
                                        <?php echo e(date('d F Y', strtotime($transaction->created_at))); ?></div>
                                </div>
                            </div>
                            <div class="flex gap-small">
                                <h5 class="text-color-dark-grey">Status</h5><a href="#"
                                    class="status-button-like w-inline-block" style="font-size:12px;">
                                    <div><?php echo e($transaction->status->name); ?></div>
                                </a>
                            </div>
                        </div>
                        <div class="div-line-sumarry"></div>
                        <?php ($current_vendor = 0); ?>
                        <?php $__currentLoopData = $transaction->cart_customs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($current_vendor != $cart->vendor_id): ?>
                                <div class="flex space-between">
                                    <div class="flex gap-small"><img src="<?php echo e(asset('uploads/'.$cart->vendor_photo)); ?>" loading="lazy"
                                            alt="" class="vendor-image" />
                                        <div>
                                            <h5 class="text-color-dark-grey"><?php echo e($cart->vendor_name); ?></h5>
                                        </div>
                                    </div>
                                </div>
                                <?php ($current_vendor = $cart->vendor_id); ?>
                            <?php endif; ?>
                            <div class="vendor-item">
                                <div class="flex gap-medium"><img src="<?php echo e(asset('uploads/'.$cart->product_featured_image)); ?>"
                                        loading="lazy" sizes="(max-width: 479px) 61vw, 70px" alt=""
                                        class="image-18" />
                                    <div>
                                        <h5 class="text-color-dark-grey"><?php echo e($cart->product_name); ?></h5>
                                        <?php if($cart->product_variation_name != 'novariation'): ?>
                                            <div class="text-size-small text-color-grey">Variant: <?php echo e($cart->product_variation_name); ?></div>
                                        <?php endif; ?>
                                        <?php if($cart->addons != null): ?>
                                            <div class="text-size-small text-color-grey">Addons: <?php echo e($cart->addons); ?></div>
                                        <?php endif; ?>
                                        <div class="text-size-small text-color-grey">$<?php echo e(number_format($cart->cart_price, 2, ".", ",")); ?></div>
                                        <!-- <div class="text-size-small text-color-grey">+ 4 more products</div> -->
                                    </div>
                                </div>
                                <div class="div-block-36">
                                    <div><?php echo e($cart->qty); ?>x</div>
                                    <div>$<?php echo e(number_format($cart->cart_price, 2, ".", ",")); ?></div>
                                </div>
                            </div>
                            <div class="div-line-sumarry"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div style="display: flex; flex-direction: row; justify-content: space-between;">
                            <div><b>Total Price</b></div>
                            <div><b>$<?php echo e(number_format($transaction->total_price, 2, ".", ",")); ?></b></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php echo e($transactions->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript-extra'); ?>
    <script src="<?php echo e(asset('assets/js/script-transaction.js')); ?>" type="text/javascript"></script>
    <script>
        var form = "#" + $(this).parents("form").attr("id");
        var param = $(location).attr("search");

        if (param != "") {
            param = param.substring(1, param.length).split("&");
            param.forEach(function(item) {
                var items = item.split("=");
                if (items[0] != "page") {
                    if ($("input[type=hidden][name=" + items[0] + "]").length <= 0) {
                        $("<input>").attr({
                            type: "hidden",
                            name: items[0],
                            value: items[1]
                        }).appendTo(form);
                    }
                }
            });
        }

        $(".delivery-button").on("click", function() {
            $(".delivery-button").each(function() {
                $(this).removeClass("selected");
            });
            $(this).addClass("selected");
        });

        $(".transaction-card").on("click", function() {
            window.location = $(this).find(".transaction-detail").attr("href");
            return false;
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bigvsgco/public_html/resources/views/user/transaction/history.blade.php ENDPATH**/ ?>
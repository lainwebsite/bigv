<div class="col-6">
    <h5>Customer Total Transactions</h5>
    <h3 class="text-orange"><b><?php echo e($transactions->count()); ?></b></h3>
    <?php
        $spend = 0;
        foreach ($transactions as $key => $transaction) {
            $spend += $transaction->total_price;
        }
    ?>
    <h5>Customer Total Spending</h5>
    <h3 class="text-orange"><b>$<?php echo e($spend); ?></b></h3>
</div>
<div class="col-6">
    <h5>Customer's Average Order Amount</h5>
    <h3 class="text-orange"><b>$<?php echo e($spend / $transactions->count()); ?></b></h3>
    <?php
        $days = 0;
        foreach ($transactions as $key => $transaction) {
            if ($key != 0) {
                $interval = $transactions[$key - 1]->created_at->diff($transactions[$key]->created_at);
                $day = $interval->format('%a');
                $days += $day;
            }
        }
        $interval = $days / ($transactions->count() - 1);
    ?>
    <h5 class="mt-3">Customer's Interval between Orders</h5>
    <h3 class="text-orange"><b><?php echo e($days); ?> day(s)</b></h3>
</div>
<?php /**PATH /home/bigvsgco/public_html/resources/views/admin/manage/customers/inc/analytics.blade.php ENDPATH**/ ?>
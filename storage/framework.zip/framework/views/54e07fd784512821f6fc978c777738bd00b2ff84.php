<?php $__env->startSection('customers-manage-selected'); ?>
    selected
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customers-manage-link-active'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- ============================================================== -->
    <!-- Page wrapper  -->
    <!-- ============================================================== -->
    <div class="page-wrapper">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="page-breadcrumb">
            <div class="row">
                <div class="col-8 align-self-center">
                    <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Customer Detail</h4>
                    <div class="d-flex align-items-center">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb m-0 p-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"
                                        class="text-muted">Dashboard</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.user.index')); ?>"
                                        class="text-muted">Customers</a></li>
                                <li class="breadcrumb-item text-muted active" aria-current="page">Customer Detail</li>
                            </ol>
                        </nav>
                    </div>
                </div>
                <div class="col-4 d-flex justify-content-end">
                    <form action="<?php echo e(route('admin.user.destroy', $user->id)); ?>" id="delete-user-form-<?php echo e($user->id); ?>"
                        method="post">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <?php if($user->ban == 0): ?>
                            <div onclick="deleteData(<?php echo e($user->id); ?>, '<?php echo e($user->name); ?>', 'ban')"
                                class="btn btn-danger d-flex gap-15x align-items-center pr-4 pl-4">
                                <i class="fa fa-ban"></i>Ban User
                            </div>
                        <?php else: ?>
                            <div onclick="deleteData(<?php echo e($user->id); ?>, '<?php echo e($user->name); ?>', 'unban')"
                                class="btn btn-light d-flex gap-15x align-items-center pr-4 pl-4">
                                <i class="fa fa-ban"></i>Unban User
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
            <!-- ============================================================== -->
            <!-- Start Page Content -->
            <!-- ============================================================== -->
            <!-- basic table -->
            <div class="row">
                <div class="col-12">
                    <div id="order-status" class="card bg-orange">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-6 d-flex">
                                    <div class="m-0">
                                        <h4 class="card-title m-0 text-white"><?php echo e($user->tier->name); ?> Tier</h4>
                                        <p class="m-0 text-white">Registered since
                                            <b><?php echo e(date_format(date_create($user->created_at), 'd/m/Y')); ?></b>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-6 d-flex justify-content-end">
                                    <div class="m-0">
                                        <h4 class="card-title m-0 text-white text-lg-right"><?php echo e($user->visits); ?> Visits</h4>
                                        <p class="m-0 text-white"><b><?php echo e($user->transactions->count()); ?> Transactions</b>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h4 class="card-title mb-4">Customer Info</h4>
                                    <p class="m-0"><?php echo e($user->name); ?></p>
                                    <p class="m-0"><?php echo e($user->phone); ?></p>
                                    <p class="m-0"><?php echo e($user->email); ?></p>
                                    <p class="m-0">Date of Birth
                                        <b><?php echo e(date_format(date_create($user->date_of_birth), 'd/m/Y')); ?></b>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">Analytics</h4>
                            <div class="align-self-center d-flex align-items-center">
                                <p class="mr-4 mb-0 text-nowrap">Start Date</p>
                                <input id="filter_start_date" type="date" id="start-date" class="form-control w-auto">
                                <p class="ml-4 mr-4 mb-0">-</p>
                                <p class="mr-4 mb-0 text-nowrap">End Date</p>
                                <input id="filter_end_date" type="date" id="end-date" class="form-control w-auto mr-4">
                                <a class="btn btn-primary text-white pr-4 pl-4" onclick="analytics();">Filter</a>
                            </div>
                            <div class="row mt-5" id="analytics-data">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- End Page wrapper  -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript-extra'); ?>
    <script>
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    </script>
    <script>
        function analytics() {
            var hostname = "<?php echo e(request()->getHost()); ?>"
            var url = ""
            if (hostname.includes('www')) {
                url = "https://" + hostname
            } else {
                url = "<?php echo e(config('app.url')); ?>"
            }
            $.post(url + "/admin/user/analytics", {
                    _token: CSRF_TOKEN,
                    start: $('#filter_start_date').val(),
                    end: $('#filter_end_date').val(),
                    id: <?php echo json_encode($user->id, 15, 512) ?>
                })
                .done(function(data) {
                    $('#analytics-data').html(data);
                })
                .fail(function(error) {
                    console.log(error);
                });
        }
    </script>
    <script>
        function deleteData(id, name, detail) {
            event.preventDefault();
            if (confirm(`Are you sure you want to ${detail} ${name}?`)) {
                document.getElementById(`delete-user-form-${id}`).submit();
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bigvsgco/public_html/resources/views/admin/manage/customers/detail.blade.php ENDPATH**/ ?>
<div class="card-body">
    <div class="table-responsive">
        <table id="zero_config" class="table table-striped">
            <thead>
                <tr>
                    <th>Vendor</th>
                    <th>Contact</th>
                    <th>Number of Products</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('admin.vendor.show', $vendor->slug)); ?>"
                                class="a-normal d-flex align-items-center">
                                <img class="d-flex br-18 mr-3" src="<?php echo e(asset('uploads/' . $vendor->photo)); ?>"
                                    width="60" alt="Generic placeholder image">
                                <div class="d-flex align-items-start flex-column">
                                    <h5 class="m-0"><b><?php echo e($vendor->name); ?></b></h5>
                                    <small class="m-0"><?php echo e($vendor->location->name); ?></small>
                                </div>
                            </a>
                        </td>
                        <td class="align-middle"><a href="mailto:<?php echo e($vendor->email); ?>"
                                target="_blank"><?php echo e($vendor->email); ?></a><br><a
                                href="tel:<?php echo e($vendor->phone); ?>"><?php echo e($vendor->phone); ?></a></td>
                        <td class="align-middle"><?php echo e($vendor->products->count()); ?></td>
                        <td class="align-middle">
                            <div class="d-flex" style="gap: 10px;">
                                <a href="<?php echo e(route('admin.vendor.edit', $vendor->id)); ?>"
                                    class="a-normal text-info"><?php echo $__env->make('admin.icons.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></a>
                                <a onclick="deleteData(<?php echo e($vendor->id); ?>, '<?php echo e($vendor->name); ?>');"
                                    class="a-normal text-danger"><?php echo $__env->make('admin.icons.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></a>
                            </div>
                        </td>
                    </tr>
                    <form action="<?php echo e(route('admin.vendor.destroy', $vendor->id)); ?>"
                        id="delete-vendor-form-<?php echo e($vendor->id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input name="_method" type="hidden" value="DELETE">
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($vendors->links()); ?>

</div>
<?php /**PATH /home/bigvsgco/public_html/resources/views/admin/manage/vendors/inc/vendor.blade.php ENDPATH**/ ?>
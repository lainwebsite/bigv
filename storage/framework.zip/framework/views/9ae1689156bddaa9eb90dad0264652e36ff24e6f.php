<?php $__env->startSection('page-title'); ?>
    Vendor - BigV
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-title'); ?>
    Vendor - BigV
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-description'); ?>
    Take a look at all the Vendors in BigV
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-image'); ?>
    <?php echo e(asset('assets/62ffbe41b946fc3a2b7b6747_Big%20V(NoTag)-ColorB%202.png')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head-extra'); ?>
    <link href="<?php echo e(asset('assets/css/style-product-list.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content" style="width: 100vw; min-width: 0 !important; max-width: 1200px; margin:auto;">
        <div class="flex flex-vertical row-gap margin-large" style="width: 85%; min-width: 980px; position:relative;">
            <div class="text-align-center orange-text">Showing result for</div>
            <h3 class="text-align-center">All Vendor</h3>
        </div>
        <div>
            <div class="flex flex-center top-align relative archive-flex"
                style="width: 100vw; min-width: 0 !important; max-width: 1200px; margin:auto auto 15vh auto;">
                <div style="display:flex; flex-direction: column; align-items:center;width: calc(100% - 288px);">
                    <div class="products-archive-grid" id="productsList" style="margin-bottom: 8vh;">
                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(url('vendors/' . $vendor->slug)); ?>" class="text-style-none">
                                <div id="w-node-_98aa59c7-5c20-8fcb-852c-972bad093e75-fac73a6c"
                                    class="product-card padding-small">
                                    <div class="text-rich-text text-size-small text-color-grey">
                                        <?php echo e($vendor->location->name); ?></div><img src="<?php echo e(asset('uploads/'.$vendor->photo)); ?>"
                                        loading="lazy" alt="" class="product-image" />
                                    <div class="product-card-stars">
                                        <?php ($arr_rating = explode('.', $vendor->rating)); ?>
                                        <?php ($first_num = $arr_rating[0]); ?>
                                        <?php while($first_num > 0): ?>
                                            <img src="<?php echo e(asset('assets/Star 1.svg')); ?>" loading="lazy" alt=""
                                                class="card-stars" />
                                            <?php ($first_num--); ?>
                                        <?php endwhile; ?>

                                        <?php if(isset($arr_rating[1])): ?>
                                            <img src="<?php echo e(asset('assets/Star 2.svg')); ?>" loading="lazy" alt=""
                                                class="card-stars" />
                                        <?php endif; ?>

                                        <?php ($remaining_rating = explode('.', 5 - $vendor->rating)[0]); ?>
                                        <?php if($remaining_rating > 0): ?>
                                            <?php while($remaining_rating > 0): ?>
                                                <img src="<?php echo e(asset('assets/Star 3.svg')); ?>" loading="lazy" alt=""
                                                    class="card-stars" />
                                                <?php ($remaining_rating--); ?>
                                            <?php endwhile; ?>
                                        <?php endif; ?>
                                    </div>
                                    <div
                                        class="product-card-title text-rich-text text-size-regular text-weight-bold text-color-dark-grey text-center text-truncate">
                                        <?php echo e($vendor->name); ?>

                                    </div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php echo e($vendors->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript-extra'); ?>
    <script src="<?php echo e(asset('assets/js/script-product-list.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bigvsgco/public_html/resources/views/user/vendor/index.blade.php ENDPATH**/ ?>
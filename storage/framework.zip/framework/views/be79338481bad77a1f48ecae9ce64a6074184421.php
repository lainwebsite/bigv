<div class="card-body">
    <div class="table-responsive">
        <table id="zero_config" class="table table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Product</th>
                    <th>Number of Transaction</th>
                    <th>Total Sold</th>
                    <th>Total Income</th>
                    <th>Rating</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="align-middle"><?php echo e($product->id); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.product.analytics.detail', $product->id)); ?>"
                                class="a-normal d-flex align-items-center">
                                <img class="d-flex br-18 mr-3" src="<?php echo e(asset('uploads/' . $product->featured_image)); ?>"
                                    width="60" alt="Generic placeholder image">
                                <div class="d-flex align-items-start flex-column">
                                    <h5 class="m-0"><b><?php echo e($product->name); ?></b></h5>
                                    <small class="m-0"><?php echo e($product->category->name); ?></small>
                                </div>
                            </a>
                        </td>
                        <td class="align-middle"><?php echo e($product->transaction_count); ?></td>
                        <td class="align-middle total-sold"><?php echo e($product->sold_count); ?></td>
                        <td class="align-middle">$<span class="total-income"><?php echo e($product->total_income); ?></span></td>
                        <td class="align-middle"><?php echo e($product->rating); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($products->links()); ?>

</div>
<?php /**PATH /home/bigvsgco/public_html/resources/views/admin/analytics/products/inc/product.blade.php ENDPATH**/ ?>
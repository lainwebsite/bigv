<div class="col pt-0 pb-0 pr-4 pl-4">
    <ul class="list-unstyled mb-5">
        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <div class="w-100 card custom-border my-2">
                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'card-header d-flex justify-content-between flex-column',
                        'bg-danger' => $transaction->status_id == 1,
                        'bg-primary' => $transaction->status_id == 2,
                        'bg-cyan' => $transaction->status_id == 3,
                        'bg-success' => $transaction->status_id == 4,
                        'bg-secondary' => $transaction->status_id == 5,
                        'bg-dark' => $transaction->status_id == 6,
                        'bg-dark' => $transaction->status_id == 7,
                    ]) ?>">
                        <div class="d-flex justify-content-between">
                            <p class="m-0 text-white">
                                <?php echo e($transaction->user->name); ?></p>
                            <p class="m-0 text-white"><?php echo e($transaction->status->name); ?>

                            </p>
                        </div>
                        <div class="d-flex justify-content-between">
                            <h6 class="m-0 text-white"><?php echo e($transaction->id); ?></h6>
                            <h6 class="m-0 text-white"><?php echo e($transaction->created_at); ?>

                            </h6>
                        </div>
                    </div>
                    <div class="card-body d-flex align-items-center" style="gap: 18px;">
                        <div class="d-flex align-items-center">
                            <div class="form-check form-check-inline m-0">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input status-checkbox"
                                        data-tid=<?php echo e($transaction->id); ?> id="checkOrder<?php echo e($transaction->id); ?>">
                                    <label class="custom-control-label" for="checkOrder<?php echo e($transaction->id); ?>"></label>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(route('admin.transaction.show', $transaction->id)); ?>" class="w-100 a-normal">
                            <div class="card-body p-0">
                                <ul class="list-unstyled">
                                    <li class="media align-items-center">
                                        <img class="d-flex mr-3 br-18"
                                            src="<?php echo e(asset('uploads/' . $transaction->carts->first()->product_variation_trashed->product_trashed->featured_image)); ?>"
                                            width="60" alt="Generic placeholder image">
                                        <div class="media-body">
                                            <h5 class="mt-0 mb-1">
                                                <b><?php echo e($transaction->carts->first()->product_variation_trashed->product_trashed->name); ?></b>
                                            </h5>
                                            <?php if($transaction->carts->first()->product_variation_trashed->name != "novariation"): ?>
                                                <h6 class="m-0"><?php echo e($transaction->carts->first()->product_variation_trashed->name); ?></h6>
                                            <?php endif; ?>
                                            <?php if($transaction->carts->first()->addon_options->count() > 0): ?>
                                                <?php 
                                                    $addonOptArr = [];
                                                ?>
                                                <?php $__currentLoopData = $transaction->carts->first()->addon_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        array_push($addonOptArr, $addon->addon_option_trashed->name);
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <h6 class="m-0">Addon: <?php echo e(join(",", $addonOptArr)); ?></h6>
                                            <?php endif; ?>
                                            <h6 class="m-0">
                                                $<?php echo e($transaction->carts->first()->price); ?></h6>
                                        </div>
                                        <p class="m-0">
                                            x<?php echo e($transaction->carts->first()->quantity); ?></p>
                                    </li>
                                </ul>
                                <?php if($transaction->carts->count() > 1): ?>
                                    <h6 class="text-right mt-1">+
                                        <?php echo e($transaction->carts->count() - 1); ?> other products
                                    </h6>
                                <?php endif; ?>
                                <div class="divider-dash"></div>
                                <div class="d-flex justify-content-between">
                                    <p class="m-0"><b>Total Payment using
                                            <?php echo e($transaction->payment_method->name); ?></b></p>
                                    <p class="m-0"><b>$<?php echo e($transaction->total_price); ?></b>
                                    </p>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php echo e($transactions->links()); ?>

</div>
<?php /**PATH /home/bigvsgco/public_html/resources/views/admin/manage/transaction/inc/transaction.blade.php ENDPATH**/ ?>
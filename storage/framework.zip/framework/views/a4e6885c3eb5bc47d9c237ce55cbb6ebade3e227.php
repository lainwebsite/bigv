<div class="card-body">
    <div class="table-responsive">
        <table id="zero_config" class="table table-striped">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Variations</th>
                    <?php if(!$vendor): ?>
                        <th>Vendor</th>
                    <?php endif; ?>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($product->variations->count() > 0): ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('admin.product.show', $product->id)); ?>"
                                    class="a-normal d-flex align-items-center">
                                    <img class="d-flex br-18 mr-3"
                                        src="<?php echo e(asset('uploads/' . $product->featured_image)); ?>" width="60"
                                        alt="Generic placeholder image">
                                    <div class="d-flex align-items-start flex-column">
                                        <h5 class="m-0"><b><?php echo e($product->name); ?></b></h5>
                                        <small class="m-0"><?php echo e($product->category->name); ?></small>
                                    </div>
                                </a>
                            </td>
                            <?php if($product->variations->first()->discount_start_date < Carbon\Carbon::now() &&
                                $product->variations->first()->discount_end_date > Carbon\Carbon::now()): ?>
                                <td class="align-middle">
                                    <s>$<?php echo e($product->variations->first()->price); ?></s><br>$<?php echo e($product->variations->first()->discount); ?>

                                </td>
                            <?php else: ?>
                                <td class="align-middle">
                                    $<?php echo e($product->variations->first()->price); ?></td>
                            <?php endif; ?>
                            <td class="align-middle">
                                <?php $__currentLoopData = $product->variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($loop->last || $product->variations->count() == 1): ?>
                                        <?php echo e($variant->name); ?>

                                    <?php else: ?>
                                        <?php echo e($variant->name); ?>,
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <?php if(!$vendor): ?>
                                <td class="align-middle"><?php echo e($product->vendor->name); ?></td>
                            <?php endif; ?>
                            <td class="align-middle">
                                <div class="d-flex" style="gap: 10px;">
                                    <a href="<?php echo e(route('admin.product.edit', $product->id)); ?>"
                                        class="a-normal text-info"><svg xmlns="http://www.w3.org/2000/svg"
                                            width="24" height="24" viewBox="0 0 24 24" fill="none"
                                            stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                            stroke-linejoin="round" class="feather feather-edit feather-icon">
                                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                        </svg></a>
                                    <a onclick="deleteData(<?php echo e($product->id); ?>, '<?php echo e($product->name); ?>');"
                                        class="a-normal text-danger"><svg xmlns="http://www.w3.org/2000/svg"
                                            width="24" height="24" viewBox="0 0 24 24" fill="none"
                                            stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                            stroke-linejoin="round" class="feather feather-trash feather-icon">
                                            <polyline points="3 6 5 6 21 6"></polyline>
                                            <path
                                                d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2">
                                            </path>
                                        </svg></a>
                                </div>
                            </td>
                        </tr>
                        <form action="<?php echo e(route('admin.product.destroy', $product->id)); ?>"
                            id="delete-product-form-<?php echo e($product->id); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input name="_method" type="hidden" value="DELETE">
                        </form>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($products->links()); ?>

</div>
<?php /**PATH /home/bigvsgco/public_html/resources/views/admin/manage/product/inc/product.blade.php ENDPATH**/ ?>
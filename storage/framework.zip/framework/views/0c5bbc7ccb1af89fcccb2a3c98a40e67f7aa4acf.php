<?php $__env->startSection('page-title'); ?>
Profile Settings - BigV
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-title'); ?>
    Profile - BigV
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-description'); ?>
    Take a look at your profile.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-image'); ?>
    <?php echo e(asset('assets/62ffbe41b946fc3a2b7b6747_Big%20V(NoTag)-ColorB%202.png')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head-extra'); ?>
<link href="<?php echo e(asset('assets/css/style-profile.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="header-section">
      <h2 class="orange-text">Profile</h2>
    </div>
    <div class="transactions-page-wrapper">
      <div class="profile-page-menu">
        <div class="flex gap-small">
          <div><b><?php echo e(auth()->user()->name); ?></b></div>
        </div>
        <div class="div-line" style="margin:0 !important;"></div>
        <div class="w-form">
          <div class="form-2">
              <a href="<?php echo e(url('/profile')); ?>" class="transaction-menus text-color-grey" style="text-decoration: none; white-space: nowrap;">Profile Settings</a>
              <a href="<?php echo e(url('/user/transaction')); ?>" class="transaction-menus text-color-grey" style="text-decoration: none;">Transactions</a>
              <a href="<?php echo e(url('/user/user-address')); ?>" class="transaction-menus text-color-grey" style="text-decoration: none;">Addresses</a>
              <a href="<?php echo e(url('/user/discount')); ?>" class="transaction-menus text-color-grey" style="text-decoration: none;">Promos</a>
          </div>
        </div>
      </div>
      <div class="profile-column" style="padding: 20px;">
        <div class="form-wrapper-profile">
          <h1 class="signup-header">Your Profile</h1>
          <div class="margin-bottom-2">Change to edit your information</div>
          <?php if(session('success')): ?>
            <p style="font-size:14px; color: #00ab41; margin: 15px 0;"><b><?php echo e(session('success')); ?></b></p>
          <?php endif; ?>
          <div class="w-form">
            <form method="POST" class="form-field-wrapper-2" action="<?php echo e(url('/profile/edit')); ?>">
                <?php echo csrf_field(); ?>
              <div class="text-field-wrapper">
                <label class="field-label">First Name</label>
                <input type="text" class="text-field-3 w-input" maxlength="256" name="name" value="<?php echo e($user->name); ?>" placeholder="e.g. Eddy" required="" />
              </div>
              <div class="text-field-wrapper">
                <label class="field-label">Email</label>
                <input type="email" class="text-field-3 w-input" maxlength="256" value="<?php echo e($user->email); ?>" placeholder="e.g. eddy.lin@email.com" readonly />
              </div>
              <div class="text-field-wrapper">
                <label class="field-label">Password</label>
                <input type="password" class="text-field-3 w-input" style="margin-bottom:10px;" maxlength="256" name="password" placeholder="Password" />
                <label class="field-label">Confirm Password</label>
                <input type="password" class="text-field-3 w-input" maxlength="256" name="password_confirmation" placeholder="Password" />
                <div class="field-description">Must be at least 8 characters</div>
                <div class="field-description">*Input a new Password to change the old Password!</div>
              </div>
              <div class="text-field-wrapper">
                <label class="field-label">Phone Number</label>
                <input type="tel" class="text-field-3 w-input" maxlength="256" value="<?php echo e($user->phone); ?>" name="phone" placeholder="e.g. 6123847502" required="" />
              </div>
              <div class="text-field-wrapper">
                <label class="field-label">Birthdate</label>
                <input type="date" class="text-field-3 w-input" maxlength="256" name="date_of_birth" value="<?php echo e($user->date_of_birth); ?>" placeholder="e.g. 19 April 2002" required="" />
              </div>
              <?php if($errors->any()): ?>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <p style="font-size:14px; color: #ed3419; margin-bottom: 15px;"><b><?php echo e($error); ?></b></p>
              <?php break; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              <input type="submit" value="Save" data-wait="Please wait..." class="button-4 w-button" />
            </form>
          </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript-extra'); ?>
<script src="<?php echo e(asset('assets/js/script-transaction.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bigvsgco/public_html/resources/views/user/profile/index.blade.php ENDPATH**/ ?>
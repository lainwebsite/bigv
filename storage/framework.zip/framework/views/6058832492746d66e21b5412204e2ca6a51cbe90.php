<?php $__currentLoopData = $shipping_discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shippingDiscount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div code="<?php echo e($shippingDiscount->code); ?>" class="delivery-add-item w-auto mr-2 ml-2 flex-column align-items-start shipping-discount-button cursor-pointer">
        <h4 class="heading-7"><b><?php echo e($shippingDiscount->code); ?></b></h4>
        <div class="text-size-small"><b><?php echo e($shippingDiscount->name); ?></b></div>
        <div class="text-size-small">Discount $<?php echo e($shippingDiscount->amount); ?></div>
        <small class="text-size-small"><?php echo e($shippingDiscount->description); ?></small>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    $(".product-discount-button").on('click', function() {
        $(".product-discount-button").removeClass("product-discount-button-active");
        $(this).addClass("product-discount-button-active");

        $(this).parent().attr("selected-voucher", $(this).attr("code"));
    });
    
    $(".shipping-discount-button").on('click', function() {
        $(".shipping-discount-button").removeClass("shipping-discount-button-active");
        $(this).addClass("shipping-discount-button-active");
        
        $(this).parent().attr("selected-voucher", $(this).attr("code"));
    });
</script><?php /**PATH /home/bigvsgco/public_html/resources/views/user/cart/itemShipDiscCheckout.blade.php ENDPATH**/ ?>
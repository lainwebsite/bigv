<?php ($userPagination = true); ?>
<?php if(auth()->guard()->check()): ?>
    
    <?php if(strpos(Request::url(), "admin") == true): ?>
        <?php ($userPagination = false); ?>
        <ul class="pagination justify-content-center">
        
            <?php if($paginator->onFirstPage()): ?>
                <li class="page-item disabled">
                    <a class="page-link" href="#" tabindex="-1">Previous</a>
                </li>
            <?php else: ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>">Previous</a>
                </li>
            <?php endif; ?>
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                
        
                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li class="page-item active"><a class="page-link" href="#"><?php echo e($page); ?></a></li>
                        <?php else: ?>
                            <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($paginator->hasMorePages()): ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>">Next</a>
                </li>
            <?php else: ?>
                <li class="page-item disabled">
                    <a class="page-link" href="#" tabindex="-1">Next</a>
                </li>
            <?php endif; ?>
        </ul>
    <?php endif; ?>
<?php endif; ?>

<?php if($userPagination == true): ?>
<div class="pagination flex justify-center margin-large" style="gap: 10px; flex-wrap:wrap;">
    <?php if(!$paginator->onFirstPage()): ?>
    <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="page pagination-not-selected text-style-none"
            style="width: auto; border-radius: 0;">
            <div class="orange-text">Previous</div>
        </a>
    <?php endif; ?>
    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        
        
        <?php if(is_array($element)): ?>
            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page == $paginator->currentPage()): ?>
                <a href="#" class="page pagination-selected text-style-none">
                        <div class="text-color-white"><?php echo e($page); ?></div>
                    </a>
                <?php else: ?>
                <a href="<?php echo e($url); ?>" class="page pagination-not-selected text-style-none">
                        <div class="orange-text"><?php echo e($page); ?></div>
                    </a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($paginator->hasMorePages()): ?>
     <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="page pagination-not-selected text-style-none"
            style="width: auto; border-radius: 0;">
            <div class="orange-text">Next</div>
        </a>
    <?php endif; ?>
</div>
<?php endif; ?><?php /**PATH /home/bigvsgco/public_html/resources/views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>
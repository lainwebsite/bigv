<?php $__currentLoopData = $product->variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <label for="salePrice"><?php echo e($variation->name); ?> - $<?php echo e($variation->price); ?></label>
    <div class="input-group mb-2">
        <div class="input-group-prepend">
            <label for="salePrice" style="border-radius: 10px 0 0 10px;" class="input-group-text">$</label>
        </div>
        <input type="number" class="form-control" id="salePrice" name="sale_price[<?php echo e($variation->id); ?>]"
            placeholder="Sale Price">
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/bigvsgco/public_html/resources/views/admin/manage/discounts/inc/variation.blade.php ENDPATH**/ ?>
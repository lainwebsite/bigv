<div class="card-body">
    <div class="table-responsive">
        <table id="zero_config" class="table table-striped">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Number of Products</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('admin.product-category.show', $category->id)); ?>" class="a-normal">
                                <div class="d-flex align-items-start flex-column">
                                    <h5 class="m-0"><b><?php echo e($category->name); ?></b></h5>
                                </div>
                            </a>
                        </td>
                        <td class="align-middle"><?php echo e($category->description); ?></td>
                        <td class="align-middle"><?php echo e($category->products->count()); ?></td>
                        <td class="align-middle">
                            <div class="d-flex" style="gap: 10px;">
                                <a href="<?php echo e(route('admin.product-category.edit', $category->id)); ?>"
                                    class="a-normal text-info"><i data-feather="edit" class="feather-icon"></i></a>
                                <a onclick="deleteData(<?php echo e($category->id); ?>, '<?php echo e($category->name); ?>');"
                                    class="a-normal text-danger"><?php echo $__env->make('admin.icons.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></a>
                            </div>
                        </td>
                    </tr>
                    <form action="<?php echo e(route('admin.product-category.destroy', $category->id)); ?>"
                        id="delete-category-form-<?php echo e($category->id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input name="_method" type="hidden" value="DELETE">
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($categories->links()); ?>

</div>
<?php /**PATH /home/bigvsgco/public_html/resources/views/admin/manage/product-category/inc/category.blade.php ENDPATH**/ ?>
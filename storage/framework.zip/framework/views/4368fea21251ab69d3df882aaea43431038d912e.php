<?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div address-id=<?php echo e($address->id); ?>

        class="delivery-add-item w-auto mr-2 ml-2 flex-column align-items-start address-button cursor-pointer"
        data-dismiss="modal">
        <h4 class="heading-7"><?php echo e($address->name); ?></h4>
        <div class="text-size-small"><?php echo e($address->phone); ?></div>
        <?php if(isset($address->block_number)): ?>
            <div class="text-size-small">
                <?php echo e($address->block_number); ?> <?php echo e($address->street); ?> <br>
                #<?php echo e($address->unit_level); ?>-<?php echo e($address->unit_number); ?> <?php echo e($address->building_name); ?><br>
                Singapore <?php echo e($address->postal_code); ?>

            </div>
        <?php else: ?>
            <div class="text-size-small">
                <?php echo e($address->unit_number); ?> <?php echo e($address->street); ?><br>
                Singapore <?php echo e($address->postal_code); ?>

            </div>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
    $(".address-button").on("click", function() {
        var addressId = $(this).attr("address-id");
        $.get(url + "/user/checkout/user-address/get-address/" + addressId).done(function(data) {
            if (data.block_number) {
                $(editAddress).html(`
                    <h4 class="heading-7">` + data.name + `</h4>
                    <div class="text-size-small">` + data.phone + `</div>
                    <div class="text-size-small">
                        ` + data.block_number + ` ` + data.street + ` <br>
                        #` + data.unit_level + `-` + data.unit_number + ` ` + data.building_name + ` <br>
                        Singapore ` + data.postal_code + `
                    </div>`);
            } else {
                $(editAddress).html(`
                    <h4 class="heading-7">` + data.name + `</h4>
                    <div class="text-size-small">` + data.phone + `</div>
                    <div class="text-size-small">
                        ` + data.unit_number + ` ` + data.street + ` <br>
                        Singapore ` + data.postal_code + `
                    </div>`);
            }

            $(editAddress).attr("selected-address", addressId);
        }).fail(function() {
            console.log("Error get user address!");
        });
    });
</script>
<?php /**PATH /home/bigvsgco/public_html/resources/views/user/cart/itemAddressCheckout.blade.php ENDPATH**/ ?>
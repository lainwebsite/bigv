<div class="card-body">
    <div class="table-responsive">
        <table id="zero_config" class="table table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Vendor</th>
                    <th>Number of Transaction</th>
                    <th>Total Income</th>
                    <th>Rating</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="align-middle"><?php echo e($loop->iteration); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.vendor.analytics.detail', $vendor->id)); ?>"
                                class="a-normal d-flex align-items-center">
                                <img class="d-flex br-18 mr-3" src="<?php echo e(asset('uploads/' . $vendor->photo)); ?>"
                                    width="60" alt="Generic placeholder image">
                                <div class="d-flex align-items-start flex-column">
                                    <h5 class="m-0"><b><?php echo e($vendor->name); ?></b></h5>
                                    <small class="m-0"><?php echo e($vendor->location->name); ?></small>
                                </div>
                            </a>
                        </td>
                        <td class="align-middle"><?php echo e($vendor->transaction_count); ?></td>
                        <td class="align-middle">$<?php echo e($vendor->total_income); ?></td>
                        <!-- Rating average dari semua product (all time) -->
                        <td class="align-middle"><?php echo e($vendor->rating); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($vendors->links()); ?>

</div>
<?php /**PATH /home/bigvsgco/public_html/resources/views/admin/analytics/vendors/inc/vendor.blade.php ENDPATH**/ ?>
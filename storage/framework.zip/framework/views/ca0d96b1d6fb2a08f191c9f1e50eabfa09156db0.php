<?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <div address-id=<?php echo e($address->id); ?> class="delivery-add-item w-auto flex-column align-items-start pickup-address-button <?php if($loop->index == 0): ?> pickup-address-button-active <?php endif; ?> cursor-pointer">
        <h4 class="heading-7"><?php echo e($address->name); ?></h4>
        <?php if(isset($address->block_number)): ?>
            <div class="text-size-small">
                <?php echo e($address->block_number); ?> <?php echo e($address->street); ?> <br>
                #<?php echo e($address->unit_level); ?>-<?php echo e($address->unit_number); ?> <?php echo e($address->building_name); ?><br>
                Singapore <?php echo e($address->postal_code); ?>

            </div>
        <?php else: ?>
            <div class="text-size-small">
                <?php echo e($address->unit_number); ?> <?php echo e($address->street); ?><br>
                Singapore <?php echo e($address->postal_code); ?>

            </div>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
    $(".pickup-address-button").on("click", function() {      
        var addressId = $(this).attr("address-id");
        $("#pickupShippingDetail").attr("selected-address", addressId);

        $(".pickup-address-button").removeClass("pickup-address-button-active");
        $(this).addClass("pickup-address-button-active");
    });
</script><?php /**PATH /home/bigvsgco/public_html/resources/views/user/cart/itemPickupAddressCheckout.blade.php ENDPATH**/ ?>
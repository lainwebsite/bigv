@extends('admin.layout')

@section('events-manage-selected')
    selected
@endsection

@section('events-manage-link-active')
    active
@endsection

@section('content')
    <!-- ============================================================== -->
    <!-- Page wrapper  -->
    <!-- ============================================================== -->
    <div class="page-wrapper">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="page-breadcrumb">
            <div class="row">
                <div class="col align-self-center">
                    <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Create Event</h4>
                    <div class="d-flex align-items-center">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb m-0 p-0">
                                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"
                                        class="text-muted">Dashboard</a>
                                </li>
                                <li class="breadcrumb-item"><a href="{{ route('admin.event.index') }}"
                                        class="text-muted">Events</a>
                                </li>
                                <li class="breadcrumb-item text-muted active" aria-current="page">Create Event</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
            <!-- ============================================================== -->
            <!-- Start Page Content -->
            <!-- ============================================================== -->
            <!-- basic table -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <form action="{{ route('admin.product.store') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <h4 class="card-title mb-4">Basic Information</h4>
                                <div class="form-group">
                                    <label for="name">Product Name</label>
                                    <input type="text" class="form-control" id="name" name="name" required
                                        placeholder="Product Name">
                                </div>
                                <div class="form-group" id="productPriceNoVariation">
                                    <label for="productPriceNoVar">Product Price</label>
                                    <input type="number" step="0.01" class="form-control" id="productPriceNoVar"
                                        name="product_price_no_var" placeholder="Product Price">
                                </div>
                                <div class="form-group">
                                    <label for="description">Product Description</label>
                                    <textarea class="form-control" id="description" name="description" required placeholder="Product Description"
                                        rows="4"></textarea>
                                </div>
                                <div class="divider-dash mt-4 mb-4"></div>
                                <h4 class="card-title mb-4">Product Images</h4>
                                <div class="form-group">
                                    <label for="productFeaturedImage">Featured Image</label>
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">Upload</span>
                                        </div>
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="productFeaturedImage"
                                                name="featured_image">
                                            <label class="custom-file-label" for="productFeaturedImage">Choose file</label>
                                        </div>
                                    </div>
                                </div>
                                <label class="mt-3">Additional Product Image</label>
                                <div id="productImageGroup"></div>
                                <p class="text-lg-right mt-4">
                                    <a href="javascript:void(0)" class="btn btn-primary text-white" id="addImage">Add
                                        an Image</a>
                                </p>
                                <div class="divider-dash mt-4 mb-4"></div>
                                <div class="form-check form-check-inline mb-3">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="addVariationCheckbox"
                                            name="with_variation">
                                        <label class="custom-control-label" for="addVariationCheckbox">Add Variation</label>
                                    </div>
                                </div>
                                <div id="addProductVariationGroup" style="display:none;">
                                    <h4 class="card-title mb-4">Product Variations</h4>
                                    <div class="form-group">
                                        <label for="variation_named">Product Variation Name</label>
                                        <input type="text" class="form-control" id="variation_named"
                                            name="variation_named" placeholder="e.g Size, Flavor, Color, etc.">
                                    </div>
                                    <div id="productVariationGroup"></div>
                                    <p class="text-lg-right mt-4">
                                        <a href="javascript:void(0)" class="btn btn-primary text-white"
                                            id="addVariation">
                                            Add a Variation</a>
                                    </p>
                                </div>
                                <div class="divider-dash mt-4 mb-4"></div>
                                <!-- PRODUCT ADDON -->
                                <h4 class="card-title mb-4">Product Add-on</h4>
                                <div id="productAddonGroup" class="d-flex flex-column" style="gap:30px;">
                                </div>
                                <p class="text-lg-right mt-4">
                                    <a href="javascript:void(0)" class="btn btn-primary text-white" id="addAddon">
                                        Add Add-on
                                    </a>
                                </p>
                                <!-- PRODUCT ADDON -->
                                <div class="d-flex mt-4 gap-15x">
                                    <button type="submit" class="btn btn-primary">Save Changes</button>
                                    <a href="{{ route('admin.product.index') }}" class="btn btn-light">Cancel</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Container fluid  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Page wrapper  -->
    <!-- ============================================================== -->
@endsection
